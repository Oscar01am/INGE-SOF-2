// Export pages
export '/pages/inicio/inicio_widget.dart' show InicioWidget;
export '/pages/inicio_sesion/inicio_sesion_widget.dart' show InicioSesionWidget;
export '/pages/mistareas/mistareas_widget.dart' show MistareasWidget;
export '/pages/registro/registro_widget.dart' show RegistroWidget;
export '/pages/tareas_completadas/tareas_completadas_widget.dart'
    show TareasCompletadasWidget;
export '/pages/modificar_perfil/modificar_perfil_widget.dart'
    show ModificarPerfilWidget;
export '/pages/detalles_tarea/detalles_tarea_widget.dart'
    show DetallesTareaWidget;
export '/pages/mi_perfil/mi_perfil_widget.dart' show MiPerfilWidget;
export '/pages/cambiar_contrasea/cambiar_contrasea_widget.dart'
    show CambiarContraseaWidget;
export '/pages/mis_contactos/mis_contactos_widget.dart' show MisContactosWidget;
export '/pages/detalles_contacto/detalles_contacto_widget.dart'
    show DetallesContactoWidget;
export '/pages/mi_actividad/mi_actividad_widget.dart' show MiActividadWidget;
export '/pages/detalles_actividad/detalles_actividad_widget.dart'
    show DetallesActividadWidget;
export '/pages/mis_contactos_anciano/mis_contactos_anciano_widget.dart'
    show MisContactosAncianoWidget;
export '/pages/homeanciano/homeanciano_widget.dart' show HomeancianoWidget;
export '/pages/elegirusuario/elegirusuario_widget.dart'
    show ElegirusuarioWidget;
export '/pages/mistareas_anciano/mistareas_anciano_widget.dart'
    show MistareasAncianoWidget;
export '/pages/detalles_tarea_anciano/detalles_tarea_anciano_widget.dart'
    show DetallesTareaAncianoWidget;
export '/pages/mi_actividad_anciano/mi_actividad_anciano_widget.dart'
    show MiActividadAncianoWidget;
