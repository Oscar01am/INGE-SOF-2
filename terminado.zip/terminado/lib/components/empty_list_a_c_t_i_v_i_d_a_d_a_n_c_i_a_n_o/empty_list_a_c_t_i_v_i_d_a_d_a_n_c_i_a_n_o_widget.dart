import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'empty_list_a_c_t_i_v_i_d_a_d_a_n_c_i_a_n_o_model.dart';
export 'empty_list_a_c_t_i_v_i_d_a_d_a_n_c_i_a_n_o_model.dart';

class EmptyListACTIVIDADANCIANOWidget extends StatefulWidget {
  const EmptyListACTIVIDADANCIANOWidget({Key? key}) : super(key: key);

  @override
  _EmptyListACTIVIDADANCIANOWidgetState createState() =>
      _EmptyListACTIVIDADANCIANOWidgetState();
}

class _EmptyListACTIVIDADANCIANOWidgetState
    extends State<EmptyListACTIVIDADANCIANOWidget> {
  late EmptyListACTIVIDADANCIANOModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EmptyListACTIVIDADANCIANOModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          'assets/images/uiList_Empty@3x.png',
          width: 230.0,
          height: 150.0,
          fit: BoxFit.fitHeight,
        ),
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'NO TIENES ACTIVIDADES',
                textAlign: TextAlign.center,
                style: FlutterFlowTheme.of(context).headlineSmall,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
