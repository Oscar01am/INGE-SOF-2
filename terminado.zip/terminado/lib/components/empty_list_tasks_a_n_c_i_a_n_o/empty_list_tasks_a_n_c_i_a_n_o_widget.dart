import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'empty_list_tasks_a_n_c_i_a_n_o_model.dart';
export 'empty_list_tasks_a_n_c_i_a_n_o_model.dart';

class EmptyListTasksANCIANOWidget extends StatefulWidget {
  const EmptyListTasksANCIANOWidget({Key? key}) : super(key: key);

  @override
  _EmptyListTasksANCIANOWidgetState createState() =>
      _EmptyListTasksANCIANOWidgetState();
}

class _EmptyListTasksANCIANOWidgetState
    extends State<EmptyListTasksANCIANOWidget> {
  late EmptyListTasksANCIANOModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EmptyListTasksANCIANOModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          'assets/images/uiList_Empty@3x.png',
          width: 230.0,
          height: 150.0,
          fit: BoxFit.fitHeight,
        ),
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'NO TIENES TAREAS PENDIENTES',
                textAlign: TextAlign.center,
                style: FlutterFlowTheme.of(context).headlineSmall,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
