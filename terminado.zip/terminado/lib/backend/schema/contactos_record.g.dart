// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contactos_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<ContactosRecord> _$contactosRecordSerializer =
    new _$ContactosRecordSerializer();

class _$ContactosRecordSerializer
    implements StructuredSerializer<ContactosRecord> {
  @override
  final Iterable<Type> types = const [ContactosRecord, _$ContactosRecord];
  @override
  final String wireName = 'ContactosRecord';

  @override
  Iterable<Object?> serialize(Serializers serializers, ContactosRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object?>[];
    Object? value;
    value = object.user;
    if (value != null) {
      result
        ..add('user')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    value = object.nombre;
    if (value != null) {
      result
        ..add('Nombre')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.numero;
    if (value != null) {
      result
        ..add('Numero')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.ffRef;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    return result;
  }

  @override
  ContactosRecord deserialize(
      Serializers serializers, Iterable<Object?> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new ContactosRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current! as String;
      iterator.moveNext();
      final Object? value = iterator.current;
      switch (key) {
        case 'user':
          result.user = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
        case 'Nombre':
          result.nombre = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'Numero':
          result.numero = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int?;
          break;
        case 'Document__Reference__Field':
          result.ffRef = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
      }
    }

    return result.build();
  }
}

class _$ContactosRecord extends ContactosRecord {
  @override
  final DocumentReference<Object?>? user;
  @override
  final String? nombre;
  @override
  final int? numero;
  @override
  final DocumentReference<Object?>? ffRef;

  factory _$ContactosRecord([void Function(ContactosRecordBuilder)? updates]) =>
      (new ContactosRecordBuilder()..update(updates))._build();

  _$ContactosRecord._({this.user, this.nombre, this.numero, this.ffRef})
      : super._();

  @override
  ContactosRecord rebuild(void Function(ContactosRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  ContactosRecordBuilder toBuilder() =>
      new ContactosRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is ContactosRecord &&
        user == other.user &&
        nombre == other.nombre &&
        numero == other.numero &&
        ffRef == other.ffRef;
  }

  @override
  int get hashCode {
    var _$hash = 0;
    _$hash = $jc(_$hash, user.hashCode);
    _$hash = $jc(_$hash, nombre.hashCode);
    _$hash = $jc(_$hash, numero.hashCode);
    _$hash = $jc(_$hash, ffRef.hashCode);
    _$hash = $jf(_$hash);
    return _$hash;
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper(r'ContactosRecord')
          ..add('user', user)
          ..add('nombre', nombre)
          ..add('numero', numero)
          ..add('ffRef', ffRef))
        .toString();
  }
}

class ContactosRecordBuilder
    implements Builder<ContactosRecord, ContactosRecordBuilder> {
  _$ContactosRecord? _$v;

  DocumentReference<Object?>? _user;
  DocumentReference<Object?>? get user => _$this._user;
  set user(DocumentReference<Object?>? user) => _$this._user = user;

  String? _nombre;
  String? get nombre => _$this._nombre;
  set nombre(String? nombre) => _$this._nombre = nombre;

  int? _numero;
  int? get numero => _$this._numero;
  set numero(int? numero) => _$this._numero = numero;

  DocumentReference<Object?>? _ffRef;
  DocumentReference<Object?>? get ffRef => _$this._ffRef;
  set ffRef(DocumentReference<Object?>? ffRef) => _$this._ffRef = ffRef;

  ContactosRecordBuilder() {
    ContactosRecord._initializeBuilder(this);
  }

  ContactosRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _user = $v.user;
      _nombre = $v.nombre;
      _numero = $v.numero;
      _ffRef = $v.ffRef;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(ContactosRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$ContactosRecord;
  }

  @override
  void update(void Function(ContactosRecordBuilder)? updates) {
    if (updates != null) updates(this);
  }

  @override
  ContactosRecord build() => _build();

  _$ContactosRecord _build() {
    final _$result = _$v ??
        new _$ContactosRecord._(
            user: user, nombre: nombre, numero: numero, ffRef: ffRef);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
