import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'contactos_record.g.dart';

abstract class ContactosRecord
    implements Built<ContactosRecord, ContactosRecordBuilder> {
  static Serializer<ContactosRecord> get serializer =>
      _$contactosRecordSerializer;

  DocumentReference? get user;

  @BuiltValueField(wireName: 'Nombre')
  String? get nombre;

  @BuiltValueField(wireName: 'Numero')
  int? get numero;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(ContactosRecordBuilder builder) => builder
    ..nombre = ''
    ..numero = 0;

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Contactos');

  static Stream<ContactosRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<ContactosRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  ContactosRecord._();
  factory ContactosRecord([void Function(ContactosRecordBuilder) updates]) =
      _$ContactosRecord;

  static ContactosRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createContactosRecordData({
  DocumentReference? user,
  String? nombre,
  int? numero,
}) {
  final firestoreData = serializers.toFirestore(
    ContactosRecord.serializer,
    ContactosRecord(
      (c) => c
        ..user = user
        ..nombre = nombre
        ..numero = numero,
    ),
  );

  return firestoreData;
}
