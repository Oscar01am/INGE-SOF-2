// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'to_do_list_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<ToDoListRecord> _$toDoListRecordSerializer =
    new _$ToDoListRecordSerializer();

class _$ToDoListRecordSerializer
    implements StructuredSerializer<ToDoListRecord> {
  @override
  final Iterable<Type> types = const [ToDoListRecord, _$ToDoListRecord];
  @override
  final String wireName = 'ToDoListRecord';

  @override
  Iterable<Object?> serialize(Serializers serializers, ToDoListRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object?>[];
    Object? value;
    value = object.toDoDate;
    if (value != null) {
      result
        ..add('toDoDate')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.toDoName;
    if (value != null) {
      result
        ..add('toDoName')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.toDoDescription;
    if (value != null) {
      result
        ..add('toDoDescription')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.toDoState;
    if (value != null) {
      result
        ..add('toDoState')
        ..add(
            serializers.serialize(value, specifiedType: const FullType(bool)));
    }
    value = object.completedDate;
    if (value != null) {
      result
        ..add('completedDate')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.user;
    if (value != null) {
      result
        ..add('user')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    value = object.toDoDateFinal;
    if (value != null) {
      result
        ..add('toDoDateFinal')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.hora;
    if (value != null) {
      result
        ..add('Hora')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.hora2;
    if (value != null) {
      result
        ..add('Hora2')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.hora3;
    if (value != null) {
      result
        ..add('Hora3')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.hora4;
    if (value != null) {
      result
        ..add('Hora4')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.hora5;
    if (value != null) {
      result
        ..add('Hora5')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.hora6;
    if (value != null) {
      result
        ..add('Hora6')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.ffRef;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    return result;
  }

  @override
  ToDoListRecord deserialize(
      Serializers serializers, Iterable<Object?> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new ToDoListRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current! as String;
      iterator.moveNext();
      final Object? value = iterator.current;
      switch (key) {
        case 'toDoDate':
          result.toDoDate = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'toDoName':
          result.toDoName = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'toDoDescription':
          result.toDoDescription = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'toDoState':
          result.toDoState = serializers.deserialize(value,
              specifiedType: const FullType(bool)) as bool?;
          break;
        case 'completedDate':
          result.completedDate = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'user':
          result.user = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
        case 'toDoDateFinal':
          result.toDoDateFinal = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'Hora':
          result.hora = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'Hora2':
          result.hora2 = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'Hora3':
          result.hora3 = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'Hora4':
          result.hora4 = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'Hora5':
          result.hora5 = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'Hora6':
          result.hora6 = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime?;
          break;
        case 'Document__Reference__Field':
          result.ffRef = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
      }
    }

    return result.build();
  }
}

class _$ToDoListRecord extends ToDoListRecord {
  @override
  final DateTime? toDoDate;
  @override
  final String? toDoName;
  @override
  final String? toDoDescription;
  @override
  final bool? toDoState;
  @override
  final DateTime? completedDate;
  @override
  final DocumentReference<Object?>? user;
  @override
  final DateTime? toDoDateFinal;
  @override
  final DateTime? hora;
  @override
  final DateTime? hora2;
  @override
  final DateTime? hora3;
  @override
  final DateTime? hora4;
  @override
  final DateTime? hora5;
  @override
  final DateTime? hora6;
  @override
  final DocumentReference<Object?>? ffRef;

  factory _$ToDoListRecord([void Function(ToDoListRecordBuilder)? updates]) =>
      (new ToDoListRecordBuilder()..update(updates))._build();

  _$ToDoListRecord._(
      {this.toDoDate,
      this.toDoName,
      this.toDoDescription,
      this.toDoState,
      this.completedDate,
      this.user,
      this.toDoDateFinal,
      this.hora,
      this.hora2,
      this.hora3,
      this.hora4,
      this.hora5,
      this.hora6,
      this.ffRef})
      : super._();

  @override
  ToDoListRecord rebuild(void Function(ToDoListRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  ToDoListRecordBuilder toBuilder() =>
      new ToDoListRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is ToDoListRecord &&
        toDoDate == other.toDoDate &&
        toDoName == other.toDoName &&
        toDoDescription == other.toDoDescription &&
        toDoState == other.toDoState &&
        completedDate == other.completedDate &&
        user == other.user &&
        toDoDateFinal == other.toDoDateFinal &&
        hora == other.hora &&
        hora2 == other.hora2 &&
        hora3 == other.hora3 &&
        hora4 == other.hora4 &&
        hora5 == other.hora5 &&
        hora6 == other.hora6 &&
        ffRef == other.ffRef;
  }

  @override
  int get hashCode {
    var _$hash = 0;
    _$hash = $jc(_$hash, toDoDate.hashCode);
    _$hash = $jc(_$hash, toDoName.hashCode);
    _$hash = $jc(_$hash, toDoDescription.hashCode);
    _$hash = $jc(_$hash, toDoState.hashCode);
    _$hash = $jc(_$hash, completedDate.hashCode);
    _$hash = $jc(_$hash, user.hashCode);
    _$hash = $jc(_$hash, toDoDateFinal.hashCode);
    _$hash = $jc(_$hash, hora.hashCode);
    _$hash = $jc(_$hash, hora2.hashCode);
    _$hash = $jc(_$hash, hora3.hashCode);
    _$hash = $jc(_$hash, hora4.hashCode);
    _$hash = $jc(_$hash, hora5.hashCode);
    _$hash = $jc(_$hash, hora6.hashCode);
    _$hash = $jc(_$hash, ffRef.hashCode);
    _$hash = $jf(_$hash);
    return _$hash;
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper(r'ToDoListRecord')
          ..add('toDoDate', toDoDate)
          ..add('toDoName', toDoName)
          ..add('toDoDescription', toDoDescription)
          ..add('toDoState', toDoState)
          ..add('completedDate', completedDate)
          ..add('user', user)
          ..add('toDoDateFinal', toDoDateFinal)
          ..add('hora', hora)
          ..add('hora2', hora2)
          ..add('hora3', hora3)
          ..add('hora4', hora4)
          ..add('hora5', hora5)
          ..add('hora6', hora6)
          ..add('ffRef', ffRef))
        .toString();
  }
}

class ToDoListRecordBuilder
    implements Builder<ToDoListRecord, ToDoListRecordBuilder> {
  _$ToDoListRecord? _$v;

  DateTime? _toDoDate;
  DateTime? get toDoDate => _$this._toDoDate;
  set toDoDate(DateTime? toDoDate) => _$this._toDoDate = toDoDate;

  String? _toDoName;
  String? get toDoName => _$this._toDoName;
  set toDoName(String? toDoName) => _$this._toDoName = toDoName;

  String? _toDoDescription;
  String? get toDoDescription => _$this._toDoDescription;
  set toDoDescription(String? toDoDescription) =>
      _$this._toDoDescription = toDoDescription;

  bool? _toDoState;
  bool? get toDoState => _$this._toDoState;
  set toDoState(bool? toDoState) => _$this._toDoState = toDoState;

  DateTime? _completedDate;
  DateTime? get completedDate => _$this._completedDate;
  set completedDate(DateTime? completedDate) =>
      _$this._completedDate = completedDate;

  DocumentReference<Object?>? _user;
  DocumentReference<Object?>? get user => _$this._user;
  set user(DocumentReference<Object?>? user) => _$this._user = user;

  DateTime? _toDoDateFinal;
  DateTime? get toDoDateFinal => _$this._toDoDateFinal;
  set toDoDateFinal(DateTime? toDoDateFinal) =>
      _$this._toDoDateFinal = toDoDateFinal;

  DateTime? _hora;
  DateTime? get hora => _$this._hora;
  set hora(DateTime? hora) => _$this._hora = hora;

  DateTime? _hora2;
  DateTime? get hora2 => _$this._hora2;
  set hora2(DateTime? hora2) => _$this._hora2 = hora2;

  DateTime? _hora3;
  DateTime? get hora3 => _$this._hora3;
  set hora3(DateTime? hora3) => _$this._hora3 = hora3;

  DateTime? _hora4;
  DateTime? get hora4 => _$this._hora4;
  set hora4(DateTime? hora4) => _$this._hora4 = hora4;

  DateTime? _hora5;
  DateTime? get hora5 => _$this._hora5;
  set hora5(DateTime? hora5) => _$this._hora5 = hora5;

  DateTime? _hora6;
  DateTime? get hora6 => _$this._hora6;
  set hora6(DateTime? hora6) => _$this._hora6 = hora6;

  DocumentReference<Object?>? _ffRef;
  DocumentReference<Object?>? get ffRef => _$this._ffRef;
  set ffRef(DocumentReference<Object?>? ffRef) => _$this._ffRef = ffRef;

  ToDoListRecordBuilder() {
    ToDoListRecord._initializeBuilder(this);
  }

  ToDoListRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _toDoDate = $v.toDoDate;
      _toDoName = $v.toDoName;
      _toDoDescription = $v.toDoDescription;
      _toDoState = $v.toDoState;
      _completedDate = $v.completedDate;
      _user = $v.user;
      _toDoDateFinal = $v.toDoDateFinal;
      _hora = $v.hora;
      _hora2 = $v.hora2;
      _hora3 = $v.hora3;
      _hora4 = $v.hora4;
      _hora5 = $v.hora5;
      _hora6 = $v.hora6;
      _ffRef = $v.ffRef;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(ToDoListRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$ToDoListRecord;
  }

  @override
  void update(void Function(ToDoListRecordBuilder)? updates) {
    if (updates != null) updates(this);
  }

  @override
  ToDoListRecord build() => _build();

  _$ToDoListRecord _build() {
    final _$result = _$v ??
        new _$ToDoListRecord._(
            toDoDate: toDoDate,
            toDoName: toDoName,
            toDoDescription: toDoDescription,
            toDoState: toDoState,
            completedDate: completedDate,
            user: user,
            toDoDateFinal: toDoDateFinal,
            hora: hora,
            hora2: hora2,
            hora3: hora3,
            hora4: hora4,
            hora5: hora5,
            hora6: hora6,
            ffRef: ffRef);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
