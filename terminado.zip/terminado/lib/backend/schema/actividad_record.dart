import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'actividad_record.g.dart';

abstract class ActividadRecord
    implements Built<ActividadRecord, ActividadRecordBuilder> {
  static Serializer<ActividadRecord> get serializer =>
      _$actividadRecordSerializer;

  DateTime? get toDoDate;

  String? get toDoDescription;

  DocumentReference? get user;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(ActividadRecordBuilder builder) =>
      builder..toDoDescription = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('actividad');

  static Stream<ActividadRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<ActividadRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  ActividadRecord._();
  factory ActividadRecord([void Function(ActividadRecordBuilder) updates]) =
      _$ActividadRecord;

  static ActividadRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createActividadRecordData({
  DateTime? toDoDate,
  String? toDoDescription,
  DocumentReference? user,
}) {
  final firestoreData = serializers.toFirestore(
    ActividadRecord.serializer,
    ActividadRecord(
      (a) => a
        ..toDoDate = toDoDate
        ..toDoDescription = toDoDescription
        ..user = user,
    ),
  );

  return firestoreData;
}
