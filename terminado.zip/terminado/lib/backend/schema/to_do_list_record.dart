import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'to_do_list_record.g.dart';

abstract class ToDoListRecord
    implements Built<ToDoListRecord, ToDoListRecordBuilder> {
  static Serializer<ToDoListRecord> get serializer =>
      _$toDoListRecordSerializer;

  DateTime? get toDoDate;

  String? get toDoName;

  String? get toDoDescription;

  bool? get toDoState;

  DateTime? get completedDate;

  DocumentReference? get user;

  DateTime? get toDoDateFinal;

  @BuiltValueField(wireName: 'Hora')
  DateTime? get hora;

  @BuiltValueField(wireName: 'Hora2')
  DateTime? get hora2;

  @BuiltValueField(wireName: 'Hora3')
  DateTime? get hora3;

  @BuiltValueField(wireName: 'Hora4')
  DateTime? get hora4;

  @BuiltValueField(wireName: 'Hora5')
  DateTime? get hora5;

  @BuiltValueField(wireName: 'Hora6')
  DateTime? get hora6;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(ToDoListRecordBuilder builder) => builder
    ..toDoName = ''
    ..toDoDescription = ''
    ..toDoState = false;

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('ToDoList');

  static Stream<ToDoListRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<ToDoListRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  ToDoListRecord._();
  factory ToDoListRecord([void Function(ToDoListRecordBuilder) updates]) =
      _$ToDoListRecord;

  static ToDoListRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createToDoListRecordData({
  DateTime? toDoDate,
  String? toDoName,
  String? toDoDescription,
  bool? toDoState,
  DateTime? completedDate,
  DocumentReference? user,
  DateTime? toDoDateFinal,
  DateTime? hora,
  DateTime? hora2,
  DateTime? hora3,
  DateTime? hora4,
  DateTime? hora5,
  DateTime? hora6,
}) {
  final firestoreData = serializers.toFirestore(
    ToDoListRecord.serializer,
    ToDoListRecord(
      (t) => t
        ..toDoDate = toDoDate
        ..toDoName = toDoName
        ..toDoDescription = toDoDescription
        ..toDoState = toDoState
        ..completedDate = completedDate
        ..user = user
        ..toDoDateFinal = toDoDateFinal
        ..hora = hora
        ..hora2 = hora2
        ..hora3 = hora3
        ..hora4 = hora4
        ..hora5 = hora5
        ..hora6 = hora6,
    ),
  );

  return firestoreData;
}
