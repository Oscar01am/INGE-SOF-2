import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCnF0bh3O8Li8FAWhPOmoQTzk_YEGWAmIw",
            authDomain: "inicio-a4cf4.firebaseapp.com",
            projectId: "inicio-a4cf4",
            storageBucket: "inicio-a4cf4.appspot.com",
            messagingSenderId: "793004653308",
            appId: "1:793004653308:web:27c6a132c796ab30377579"));
  } else {
    await Firebase.initializeApp();
  }
}
